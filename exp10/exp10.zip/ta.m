function [ua,va,za]=ta(ub,vb,zb,m,n)
%     transmiting arrays  ���鴫��

        ua=ub;
        va=vb;
        za=zb;


% for i=1:m
%     for j=1:n
%         ua(i,j)=ub(i,j);
%         va(i,j)=vb(i,j);
%         za(i,j)=zb(i,j);
%     end
% end
return

